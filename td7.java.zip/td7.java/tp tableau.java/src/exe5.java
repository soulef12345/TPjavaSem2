import java.util.Scanner;

public class exe5 {
    public static void main(String[] args) {
        int[] tableau = { 3, 7, 1, 9, 4 };

        System.out.println("Tableau original:");
        afficher(tableau);

        tri(tableau);
        System.out.println("\nTableau trié:");
        afficher(tableau);

        System.out.println("\nMaximum: " + Max(tableau));
    }

    static void afficher(int[] t) {
        for (int val : t) {
            System.out.print(val + " ");
        }
    }

    static void tri(int[] t) {
        for (int i = 0; i < t.length - 1; i++) {
            for (int j = i + 1; j < t.length; j++) {
                if (t[i] > t[j]) {
                    int temp = t[i];
                    t[i] = t[j];
                    t[j] = temp;
                }
            }
        }
    }

    static int Max(int[] t) {
        int max = t[0];
        for (int val : t) {
            if (val > max)
                max = val;
        }
        return max;
    }
}