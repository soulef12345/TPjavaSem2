import java.util.Scanner;

public class ex2 {
    public static int lectureN() {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Donnez un entier positif <= 20 : ");
            n = sc.nextInt();
        } while (n <= 0 || n > 20);
        return n;
    }

    public static void Remplir(float[] T, int n) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < n; i++) {
            do {
                System.out.print("note " + (i + 1) + " entre 0 et 20 : ");
                T[i] = sc.nextFloat();
            } while (T[i] < 0 || T[i] > 20);
        }
    }

    public static float CalculMoy(float[] T, int n) {
        float s = 0;
        for (int i = 0; i < n; i++) {
            s = s + T[i];
        }
        return s / n;
    }

    public static int nbNote(float[] T, int n, float moy) {
        int nb = 0;
        for (int i = 0; i < n; i++) {
            if (T[i] > moy) {
                nb++;
            }
        }
        return nb;
    }

    public static void main(String[] args) {
        int n = lectureN();
        float[] T = new float[n];
        Remplir(T, n);
        float moy = CalculMoy(T, n);
        int nbSup = nbNote(T, n, moy);
        System.out.println("La moyenne de la classe est : " + moy);
        System.out.println("Nombre de notes supérieures à la moyenne : " + nbSup);
    }
}
