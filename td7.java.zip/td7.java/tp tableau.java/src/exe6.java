import java.util.Scanner;

public class exe6 {

    public static int maxTableau(int[] tab) {
        if (tab.length == 0) {
            throw new IllegalArgumentException(" ");
        }

        int max = tab[0];
        for (int i = 1; i < tab.length; i++) {
            if (tab[i] > max) {
                max = tab[i];
            }
        }
        return max;
    }

    public static void main(String[] args) {
        int[] t = { 5, 7, 99, 13, 27, 3 };
        System.out.println("Le maximum est : " + maxTableau(t));
    }
}