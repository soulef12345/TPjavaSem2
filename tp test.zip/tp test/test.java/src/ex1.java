import java.util.Scanner;

public class ex1 {
        public static int lecture() {
            Scanner sc = new Scanner(System.in);
            int n;
            do {
                System.out.print("Entrez un entier strictement positif : ");
                n = sc.nextInt();
            } while (n <= 0);
            return n;
        }
    
        public static int cp(int nb) {
            return String.valueOf(nb).length();
        }
    
        public static void main(String[] args) {
            int n = lecture();
            System.out.println("Nombre de chiffres : " + cp(n));
        }
    }