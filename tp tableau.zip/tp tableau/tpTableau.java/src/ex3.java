import java.util.Scanner;

public class ex3 {
    public static int lectureN() {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Donnez un entier strictement positif : ");
            n = sc.nextInt();
        } while (n <= 0);
        return n;
    }

    public static void Remplir(int[] t, int n) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < n; i++) {
            do {
                System.out.print("t[" + i + "] = ");
                t[i] = sc.nextInt();
            } while (t[i] < 0);
        }
    }

    public static int[] CreertPair(int[] t, int n1) {
        int[] tpair = new int[50];
        int i, j;
        j = 0;
        for (i = 0; i < n1; i++) {
            if (t[i] % 2 == 0) {
                tpair[j] = t[i];
                j = j + 1;
            }
        }
        return tpair;
    }

    public static int[] Creertimpair(int[] t, int n2) {
        int[] timpair = new int[50];
        int i, j;
        j = 0;
        for (i = 0; i < n2; i++) {
            if (t[i] % 2 != 0) {
                timpair[j] = t[i];
                j = j + 1;
            }
        }
        return timpair;
    }

    public static void AfficheTAB(int[] t, int n) {
        int i;
        for (i = 0; i < n; i++) {
            System.out.println("t[" + i + "] = " + t[i]);
        }
    }

    public static void main(String[] args) {
        int[] t = new int[50];
        int[] tpair = new int[50];
        int[] timpair = new int[50];
        int n, n1, n2;
        n = lectureN();
        Remplir(t, n);
        tpair = CreertPair(t, n);
        n1 = tpair.length;
        timpair = Creertimpair(t, n);
        n2 = timpair.length;
        AfficheTAB(tpair, n);
        System.out.println("t[i]");
        AfficheTAB(timpair, n);
    }
}
