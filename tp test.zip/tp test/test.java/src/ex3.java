import java.util.Scanner;

public class ex3 {
    public static boolean estInfinitif(String v) {
        return v.endsWith("er") || v.endsWith("ir") || v.endsWith("re") || v.endsWith("oir");
    }

    public static int groupe(String v) {
        if (v.equals("aller"))
            return 3;
        if (v.endsWith("er"))
            return 1;
        if (v.endsWith("ir")) {
            String r = v.substring(0, v.length() - 2);
            if (r + "issant" != null)
                return 2;
        }
        return 3;
    }

    public static void verb() {
        Scanner sc = new Scanner(System.in);
        String v;
        do {
            System.out.print("Entrez un verb à l'infinitif : ");
            v = sc.nextLine().toLowerCase();
        } while (!estInfinitif(v));
        System.out.println("verb accepté : " + v);
    }

    public static void afficher() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrez un verb à l'infinitif : ");
        String v = sc.nextLine().toLowerCase();
        if (estInfinitif(v)) {
            System.out.println("Ce verb appartient au groupe : " + groupe(v));
        } else {
            System.out.println("Ce n'est pas un verb à l'infinitif.");
        }
    }

    public static void main(String[] args) {
        verb();
        afficher();
    }
}