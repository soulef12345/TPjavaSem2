import java.util.Scanner;

public class exe3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Donner la taille du tableau : ");
        int n = scanner.nextInt();

        int[] t = new int[n];
        remplir(t);

        System.out.println("Tableau initial :");
        afficher(t);
        System.out.println();

        trier(t);

        System.out.println("Tableau trié :");
        afficher(t);
    }

    static void remplir(int[] t) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Donner les éléments du tableau :");
        for (int i = 0; i < t.length; i++) {
            t[i] = scanner.nextInt();
        }
    }

    static void trier(int[] t) {
        int aux;
        for (int i = 0; i < t.length - 1; i++) {
            for (int j = i + 1; j < t.length; j++) {
                if (t[i] > t[j]) {
                    aux = t[i];
                    t[i] = t[j];
                    t[j] = aux;
                }
            }
        }
    }

    static void afficher(int[] t) {
        for (int i = 0; i < t.length; i++) {
            System.out.print(t[i] + " ");
        }
        System.out.println();
    }
}