import java.util.Scanner;

public class ex1 {
    public static int lecturen() {
        Scanner Scanner = new Scanner(System.in);
        int n;
        do {
            System.out.println("donne un entier");
            n = Scanner.nextInt();

        } while (n <= 0 || n > 100);
        return n;

    }

    public static void remplirTab(int t[], int n) {
        Scanner Scanner = new Scanner(System.in);

        for (int i = 0; i < n; i++) {
            System.out.println("Entrez l'entier numéro " + (i + 1) + " : ");
            t[i] = Scanner.nextInt();
        }

    }

    public static void Remplacer(int t[], int n, int x1, int x2) {
        for (int i = 0; i < n; i++) {
            if (t[i] == x1) {
                t[i] = x2;

            }
        }

    }

    public static void AfficheTab(int t[], int n) {
        System.out.println("Contenu du tableau :");
        for (int i = 0; i < n; i++) {
            System.out.println(t[i]);
        }

    }

    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        int n = lecturen();
        int t[] = new int[n];
        remplirTab(t, n);
        System.out.println("donner deux entiers");
        int x1 = Scanner.nextInt();
        int x2 = Scanner.nextInt();
        Remplacer(t, n, x1, x2);
        AfficheTab(t, n);
    }
}
