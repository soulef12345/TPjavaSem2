import java.util.Scanner;

public class exe2 {

    public static int lecture() {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Donnez un entier strictement positif : ");
            n = sc.nextInt();
        } while (n <= 0);
        return n;
    }

    public static int produit(int t1[], int t2[]) {
        int s = 0;
        if (t1.length != t2.length) {
            return 0;
        }
        for (int i = 0; i < t1.length; i++) {
            s = s + t1[i] * t2[i];
        }
        return s;
    }

    public static int[] somme(int t1[], int t2[]) {
        int n = t1.length;
        if (n != t2.length) {
            return null;
        }
        int t3[] = new int[n];
        for (int i = 0; i < n; i++) {
            t3[i] = t1[i] + t2[i];
        }
        return t3;
    }

    public static void affiche(int t[]) {
        for (int i = 0; i < t.length; i++) {
            System.out.print(t[i] + " ");
        }
        System.out.println();
    }

    public static void remplir(int t[]) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < t.length; i++) {
            System.out.print("Entrez le nombre " + i + " : ");
            t[i] = sc.nextInt();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = lecture();
        int t1[] = new int[n];
        int t2[] = new int[n];
        int t3[] = new int[n];

        remplir(t1);
        remplir(t2);

        int pr = produit(t1, t2);
        System.out.println("Le produit scalaire : " + pr);

        t3 = somme(t1, t2);
        System.out.println("La somme des tableaux : ");
        affiche(t3);

    }
}
