import java.util.Scanner;

public class ex2 {
    public static double add(double a, double b) {
        return a + b;
    }

    public static double st(double a, double b) {
        return a - b;
    }

    public static double mlt(double a, double b) {
        return a * b;
    }

    public static double div(double a, double b) {
        if (b == 0) {
            System.out.println(" division par zéro !");
            return Double.NaN;
        }
        return a / b;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrez le premier nombre : ");
        double a = sc.nextDouble();
        System.out.print("Entrez le second nombre : ");
        double b = sc.nextDouble();
        System.out.print("Choisissez l'opération : ");
        char op = sc.next().charAt(0);

        double resultat = 0;
        switch (op) {
            case '+':
                resultat = add(a, b);
                break;
            case '-':
                resultat = st(a, b);
                break;
            case '*':
                resultat = mlt(a, b);
                break;
            case '/':
                resultat = div(a, b);
                break;
            default:
                System.out.println("Opération invalide.");
                return;
        }

        System.out.println("Résultat : " + resultat);
    }
}
