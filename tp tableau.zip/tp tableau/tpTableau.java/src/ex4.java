import java.util.Scanner;

public class ex4 {

    public static int lectureN() {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Donnez un entier strictement positif : ");
            n = sc.nextInt();
        } while (n <= 0);
        return n;
    }

    public static void RemplirTAB(int[][] M, int n, int m) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print("M[" + i + "][" + j + "] = ");
                M[i][j] = sc.nextInt();
            }
        }
    }

    public static int CalculSomme(int[][] M, int m, int i) {
        int s = 0;
        for (int j = 0; j < m; j++) {
            s += M[i][j];
        }
        return s;
    }

    public static void main(String[] args) {
        int n = lectureN();
        int m = lectureN();
        int[][] M = new int[n][m];
        RemplirTAB(M, n, m);
        for (int i = 0; i < n; i++) {
            int sommeL = CalculSomme(M, m, i);
            System.out.println("Somme de la ligne " + i + " = " + sommeL);
        }
    }
}
