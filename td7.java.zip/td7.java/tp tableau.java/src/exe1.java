import java.util.Scanner;

public class exe1 {

    public static double Som(double[] T) {
        double S = 0;
        for (double v : T) {
            S += v;
        }
        return S;
    }

    public static void increment(double[] T, double v) {
        for (int i = 0; i < T.length; i++) {
            T[i] += v;
        }
    }

    public static void afficher(double[] T) {
        for (double v : T) {
            System.out.print(v + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        double[] T = { 1.2, 3.4, 5.6, 7.8 };
        System.out.println("S : " + Som(T));

        System.out.println("T avant incrémentation:");
        afficher(T);

        increment(T, 2.0);
        System.out.println("T après incrémentation:");
        afficher(T);
    }

}